%%***********************************************************************
%% primPPMmod: solve a nuclear norm minimization problem (NNM) by the 
%%             primal proximal point method where the subproblems are 
%%             solved by a projected gradient method. 
%%
%%  (NNM) min { sum(svd(X)): norm(b1-A1(X)) <= delta, b2-A2(X) = 0 } 
%%
%%  where the scalar delta, the linear maps A1,A2,
%%  and the vectors b1,b2 are given.  
%%  The decision variable X is nrxnc matrix, not necessarily symmetric.
%%
%%  [X,iter,ttime,sd,runhist] = primPPMmod(Amap,ATmap,bb,delta,nr,nc,m1,m2,par)
%%
%%  Input. 
%%  Amap  : evaluate the map A(X)   = [A1(X); A2(X)]
%%  ATmap : evaluate the map A^*(y) = [A1^*(y), A2^*(y)]
%%  bb    : [b1; b2]
%%  delta : a nonnegative scalar
%%  nr,nc : dimension of X
%%  m1    : length of b1 (=0 if b1 does not exist)
%%  m2    : length of b2 (=0 if b2 does not exist)
%%  par   : a structure array of parameters
%%
%%  Output:
%%  if X is numeric, then X = standard nrxnc matrix
%%  if X is a structure, then matrix = X.U*X.V';
%%
%%  This version is slightly different from primPPMmod.m that scaling X and
%%  y are used.
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%************************************************************************

   function [X,iter,ttime,sd,runhist] = primPPMmod(Amap,ATmap,bb,delta,nr,nc,m1,m2,par)

   clear global  %% important 
   global X Xold Grad

   if ~exist('par'); par = []; end
   nmin = min(nr,nc);
   randnstate = randn('state'); randstate = rand('state');
   randn('state',5); rand('state',5);
%%
   toltarget  = 1e-4;
   maxoutiter = 20;  
   maxsubiter = 20; 
   maxrank    = min(nmin,100); 
   verbose    = 1;
   plotyes    = 0;
   linesearch   = 1; 
   continuation = 0; 
   truncation   = 1;
   truncation_gap = 3; 
   noiseratio   = 0; 
 
   tstart = clock;
   if isfield(par,'tol'); toltarget = par.tol; end
   if isfield(par,'maxsubiter'); maxsubiter = par.maxsubiter; end
   if isfield(par,'maxoutiter'); maxoutiter = par.maxoutiter; end
   if isfield(par,'maxrank'); maxrank = par.maxrank; end
   if isfield(par,'verbose'); verbose = par.verbose; end
   if isfield(par,'plotyes'); plotyes = par.plotyes; end
   if isfield(par,'linesearch');   linesearch = par.linesearch; end   
   if isfield(par,'continuation'); continuation = par.continuation; end
   if isfield(par,'truncation');   truncation = par.truncation; end
   if isfield(par,'truncation_gap'); truncation_gap = par.truncation_gap; end
   if isfield(par,'noiseratio');   noiseratio = par.noiseratio; end
%%
   if ~isa(Amap,'function_handle') || ~isa(ATmap,'function_handle')
      error('Amap and ATmap must be function handles.');
   end
%%
%% initial mu and target mu
%%
   svds_options.tol = 1e-6;    
   Grad = ATmap(bb); 
   maxsvdAtb = svds(Grad,1,'L',svds_options); maxsvdAtb = full(maxsvdAtb); 
%%
%% estimate Lipschitz constant = largest eigenvalue of Amap(ATmap). 
%%
   mm = length(bb);
   if (mm ~= m1+m2)
       error('dimension of b should be m1+m2.');
   end
   AAT_is_identity = 0; 
   AX = randn(mm,1);
   AY = Amap(ATmap(AX)); 
   if (norm(AX-AY) < 1e-16*norm(AX)); 
      AAT_is_identity = 1; 
      Lipschitz_const = 1; 
   end
   if (AAT_is_identity==0)
      options.tol   = 1e-6; 
      options.issym = true; 
      options.disp  = 0; 
      options.v0    = randn(mm,1);
      Lipschitz_const = eigs(@(y)Amap(ATmap(y)),mm,1,'LM',options); 
      Lipschitz_const = full(Lipschitz_const); 
   end
%%    
   sig = max(1e3,nmin); %% better
%%
%% Initialization
%%
   svp = 5; 
   sv  = svp; 
   if (max(nr,nc) < 1000);  
      matrix_format = 'standard';
   else
      matrix_format = 'factors'; 
   end   
   if (nmin <= 1000)
      fullsvdswitch = 200;
   else
      fullsvdswitch = max(floor(nmin/10)+100,200);
   end
   if (verbose); 
      fprintf('\n\n  nr = %2.0d, nc = %2.0d, mm = %2.0d',nr,nc,mm); 
      fprintf('\n  maxsvdAtb   = %3.2e',maxsvdAtb); 
      fprintf('\n  Lipschitz const = %3.2e',Lipschitz_const);  
      fprintf('\n  matrix storage format = %s',matrix_format);
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------');
      fprintf('\n       primal PPMmod ') 
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------'); 
      fprintf('\n   it     sig       tau       svp     relRp      relb_AX'); 
      fprintf('  relobjdiff     obj       ')
      if (verbose == 2)
          fprintf('objline      proj_type   time');
      else
          fprintf('time');
      end
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------');  
   end   
%%
   if strcmp(matrix_format,'standard')
       X = sparse(nr,nc);
   else
       X.U  = sparse(nr,1); X.V = sparse(nc,1);
   end
   Xold = X; 
   normX = 0; 
   normbb = norm(bb,'fro');
   normb = max(normbb,1);   
   constmp = 1.2*nr*nc/mm;
   const = ceil(sig/(constmp*maxsvdAtb));
   y     = (const*constmp/sig)*bb; %% dual multiplier
   b_AX  = bb; 
   normb_AX = normb; 
   normRd   = inf; relRd = inf; 
   if (delta > 0)
      cone_type = 'q'; 
      y0 = norm(y); 
   else
      cone_type = 'u'; 
      y0 = 0;
   end
   b0 = -inf; b0old = b0; 
   ybest = y;   
   Xbest = X;   
   svbest = sv; 
   minrelb_AX = inf;
   relnormXdiffbest = inf;
   
   scaleX = 1; %% 0 is better
   alpha  = 1;
%%
   runhist = struct('obj',[],'relb_AX',[],'relobjdiff',[],...
                    'tau',[],'sig',[],'svp',[],'sv',[]);
%%
param.nr   = nr; 
param.nc   = nc; 
param.verbose       = verbose; 
param.plotyes       = plotyes; 
param.maxrank       = maxrank; 
param.truncation    = truncation;
param.fullsvdswitch = fullsvdswitch;
%%
%%---------------------------------------------
%% main
%%---------------------------------------------
%%
   taumax = Lipschitz_const; 
   taumin = 1e-3*Lipschitz_const; 
   use_ybest_count = 0; 

   for outiter = 1:maxoutiter

      if (outiter == 1); 
         tau = taumax;
         maxsubitertmp = 10; %% important
         tolsub = 1; 
      else
         maxsubitertmp = min(maxsubiter,outiter*5);
      end
      tolsub = max(0.5*toltarget,min(0.5*tolsub,0.01*normRd));
      breakyes = 0;
      msg      = '';
      ysub     = sig*y; 
      ysub0    = sig*y0; 
      b0old    = max(b0old,b0); 
      %%---------------------------------------------
      %% solve inner subproblem
      %%---------------------------------------------
      clear subhist; 
      for iter = 1:maxsubitertmp          

         %% important to update b0 at each inner iteration
         if (delta > 0)
            b0 = max(b0old,-0.5*normb_AX); 
         else
            b0 = 0; 
         end
         if (iter==1) && (verbose)
            fprintf('\n  ------------- b0 = %3.2e, tolsub = %3.2e',b0,tolsub); 
         end
         if (sv == svp) && (iter > 10 || outiter > 1) 
            sv = min(svp+5,nmin);
         else
            sv = min(svp+1,nmin);
         end 
         if (outiter <= 2); svdtol = 1e-6; else svdtol = 1e-8; end
         if (iter <= 5) && (outiter == 1); 
             gap = inf; 
         else
             gap = truncation_gap; 
         end
         if (iter==1) 
            objold  = 0; %% important
            ysubold = ysub; ysub0old = ysub0; 
            b_AXold = b_AX; 
            normb_AXold = normb_AX; 
	        proj_type = '';
            tau = min(taumax,tau/0.8); %% useful
	     else
            [ysub,ysub0,proj_type] = ...
            ProjCone(ysubold+b_AXold/tau,ysub0old+b0/tau,cone_type,m1);
         end
         Grad = ATmap(ysub); 
         param.matrix_format = matrix_format; 
         param.beta1 = 1; 
         param.beta2 = 0; 
         param.beta3 = -1;     
         if (iter > 1); param.verbose = 1; else  param.verbose = 0; end
         [Xnew.U,Xnew.V,sd,svp,reserr,d] = proxmap(sv,1,sig,svdtol,gap,param);
         if (max(reserr) == 0) && (verbose == 2); fprintf('[f]'); end
         AX        = Amap(Xnew); 
         b_AX      = bb - AX;
         normXnew  = norm(sd); 
         if strcmp(matrix_format,'standard')
             trXXnew  = sum(sum(Xnew.U.*(X*Xnew.V)));
         else
             trXXnew  = sum(sum((X.U'*Xnew.U).*(X.V'*Xnew.V)));
         end         
         normXdiff = sqrt(normXnew^2+normX^2-2*trXXnew);
         relnormXdiff = normXdiff/max(1,normX); 	     
         normRd    = (1/sig)*normXdiff; 
	     relRd     = normRd/max(1,normX); 
         normAX = norm(AX);
         AXbb   = AX'*bb;
         if (delta > 0)
            [Rp,Rp0] = ProjCone(ysubold+b_AX/tau,ysub0old+b0/tau,cone_type,m1); 
            normRp = tau*sqrt(norm(Rp-ysub)^2+(Rp0-ysub0)^2);
         else
            normRp = sqrt(normAX^2+normbb^2-2*AXbb); 
         end
         relRp = normRp/normb; 
         obj   = 0.5*norm(sd)^2 - (bb'*ysub+b0'*ysub0); 
         relobjdiff = abs(obj-objold)/max(1,abs(obj));
   	     objline = objold - 1e-2*(b_AXold'*(ysub-ysubold)+b0'*(ysub0-ysub0old));
         if (scaleX == 1)
            alpha = AXbb/normAX^2;
         end
         normb_AX = sqrt(alpha^2*normAX^2+normbb^2-2*alpha*AXbb);
         relb_AX  = normb_AX/normb;
         minrelb_AX = min(relb_AX,minrelb_AX);
         %%
         subhist.obj(iter)        = -obj/sig; 
         subhist.relb_AX(iter)    = relb_AX;
	     subhist.relRd(iter)      = relRd; 
         subhist.relobjdiff(iter) = relobjdiff;  
         subhist.tau(iter)        = tau;
         subhist.svp(iter)        = svp; 
         subhist.sv(iter)         = sv; 
         if (verbose)
            fprintf('\n   %2.0d  %3.2e %3.2e |%3.0d %3.0d| ',...
                    iter,sig,tau,svp,sv);
            fprintf('%3.2e %3.2e| %3.2e %- 5.4e|',...
                    relRp,relb_AX,relobjdiff,obj); 
            if (scaleX == 1) && (verbose == 2); fprintf(' %3.2e',alpha); end
            if (verbose == 2); fprintf('%- 5.4e <%s>',objline,proj_type); end
         end
         %%
         %% record best ysub
         %%
         if (relb_AX <= minrelb_AX+1e-8); 
            ybest  = ysub; 
            ybest0 = ysub0;  
            Xbest  = X;
            alphabest = alpha; 
            svbest    = sv; 
            normXbest = normX; 
            relnormXdiffbest = relnormXdiff;
         end 
         %% 
         %% check stopping criterion
         %%
	     if (outiter > 2) && (iter > 1) 
            if (iter > 4) && (relRp  < tolsub) 
               msg = sprintf(' relRp < %3.2e',tolsub);
               termflag = '<a>'; 
               breakyes = 1; 
            end
            idx = [max(2,iter-2):iter];
            ratio = subhist.relb_AX(idx-1)./subhist.relb_AX(idx); 
            if (iter > 4) && (all(ratio-1 < 1e-2))
                msg = sprintf('lack of progress in relb_AX : %2.1e',max(ratio-1));
                termflag = '<b>'; 
                breakyes = 1;
                tau = max(taumin,0.4*tau);
            end
            if (outiter > 3) && (iter > 3) && (min(subhist.relb_AX(idx)) >= 0.99*minrelb_AX) ...
                    && (relnormXdiff < 0.1) && (all(ratio-1 < 0.05));
                msg = sprintf('lack of progress in relb_AX');
                termflag = '<c>'; 
                breakyes = 1;
                tau = max(taumin,0.4*tau);
            end
	        if (normb_AX > 10*normb_AXold) && (svp ~= subhist.svp(iter-1))
                msg = sprintf('normb_AX jumped!');
                termflag = '<d>'; 
                breakyes = 1; 
            end
            if (breakyes); fprintf('\n  %s %s',termflag,msg); break; end
         end
         %%
         %% perform linesearch to update tau. 
         %%         
	     if (linesearch) && (iter > 1)
             const_eta1 = 0.7;
	         const_eta2 = 0.8;
	         const_eta3 = 0.9;
             steptol = 1e-8*max(1,abs(obj));
	         if (obj-objline < steptol)
                 if (relRp > 2*relRpold)
                     tau = min(taumax,tau/const_eta1);
	                 flag = 2;
                 elseif (relRp > 0.8*relRpold)
                     tau = min(taumax,max(taumin,const_eta1*tau));
	                 flag = 1.1;
                 else
                     tau = min(taumax,max(taumin,const_eta3*tau));
                     flag = 1.2;
                 end
             else
                 tau = min(taumax,2*tau/const_eta2); %% 2 is important
                 flag = -1;
             end
             if (verbose == 2); fprintf('[%- 3.1f]',flag); end
         end
         if (verbose); fprintf(' %3.2e|',etime(clock,tstart)); end
         ysubold  = ysub; ysub0old = ysub0; 
         objold   = obj; 
	     relRpold = relRp;  
         b_AXold  = b_AX;
	     normb_AXold = normb_AX;
      end
      %%---------------------------------------------
      %% end of inner subproblem
      %%---------------------------------------------
      update_primal = 1;
      if (update_primal)
         if (norm(ybest-ysub) > 0) && (outiter > 1)
            X    = Xbest; 
            Xold = Xbest;
            normXold = normXbest;
            alpha = alphabest;
            y  = ybest/sig;
            y0 = ybest0/sig;
            Grad = ATmap(ybest); 
            param.verbose = 0; 
            [Xnew.U,Xnew.V,sd,svp] = proxmap(svbest,1,sig,svdtol,gap,param);
            AX   = Amap(Xnew);
            b_AX = bb - AX;
            normAX = norm(AX);
            AXbb   = AX'*bb;
            normb_AX = sqrt(alpha^2*normAX^2+normbb^2-2*alpha*AXbb);  
            obj      = 0.5*norm(sd)^2 - (bb'*ybest+b0'*ybest0); 
            obj      = alpha*obj;
            taumin = min(taumax,taumin/0.8);
            fprintf('\n ********** use ybest: relb_AX = %3.2e',normb_AX/normb); 
         else 
            normXold = normX;
            Xold = X;
            y  = ysub/sig;
            y0 = ysub0/sig;
         end
         %%
         %% Scale X and y;
         %%
         y  = alpha*y;  % better
         y0 = alpha*y0; % better
         %%
         if strcmp(matrix_format,'standard')
             X       = alpha*Xnew.U*Xnew.V';
             trXXold = alpha*sum(sum(Xnew.U.*(Xold*Xnew.V)));
             normX   = alpha*sqrt(sum(sum((Xnew.U'*Xnew.U).*(Xnew.V'*Xnew.V))));
         else
             X.U = alpha*Xnew.U; X.V = Xnew.V;
             trXXold = sum(sum((Xold.U'*X.U).*(Xold.V'*X.V)));
             normX   = sqrt(sum(sum((X.U'*X.U).*(X.V'*X.V))));
         end
         normXdiff = sqrt(normX^2+normXold^2-2*trXXold);
	     normRd    = (1/sig)*normXdiff; 
	     relnormXdiff = normXdiff/max(1,normX); 
         runhist.iter(outiter)       = iter;
         runhist.obj(outiter)        = -obj/sig;
         runhist.sig(outiter)        = sig;
         runhist.svp(outiter)        = svp;
         runhist.sv(outiter)         = sv;
         runhist.Rd(outiter)         = normRd; 
	     runhist.minrelb_AX(outiter) = min(subhist.relb_AX);
	     fprintf('\n  outiter = %d, normRd = %3.2e, relRd = %3.2e,',...
                 outiter,normRd,relRd); 
	     fprintf(' relnormXdiff = %3.2e, relnormXdiffbest = %3.2e',...
                 relnormXdiff,relnormXdiffbest); 
	     fprintf('\n               relRp = %3.2e, relb_AX = %3.2e',relRp,relb_AX); 
	     if (relRp < toltarget)
             msg = sprintf('relRp < toltarget = %3.2e',toltarget); 
             fprintf('\n ********** %s',msg);
             break; 
         end
         if (outiter > 3) 
            ratio = runhist.minrelb_AX(outiter)/min(runhist.minrelb_AX(1:outiter-1));
            use_ybest_count = use_ybest_count + 1;
            if (ratio > 0.98) && ((relnormXdiffbest < 0.1) || (use_ybest_count > 2))
               msg = sprintf('no progress in relb_AX: ratio=%2.1e',min(ratio));
               fprintf('\n ********** %s',msg);
               break; 
            end
         end
      end
   end 
   sinmax = max(sd);
   sinmin = min(sd(sd>0));
   ttime  = etime(clock,tstart);
%%
%% Print results
%%
   iter = sum(runhist.iter); 
   runhist.mu = 1./runhist.sig;
   if (verbose)
      fprintf(1,'\n Finished the main algorithm!\n')
      fprintf(1,' Objective function        = %6.5e\n',sum(sd));
      fprintf(1,' Number of iterations      = %2.0d\n',iter);
      fprintf(1,' Number of singular values = %2.0d\n',svp);
      fprintf(1,' max singular value        = %3.2e\n',sinmax);
      fprintf(1,' min singular value        = %3.2e\n',sinmin);
      fprintf(1,' CPU time                  = %3.2e\n',ttime);
      fprintf(1,' relnormXdiff              = %3.2e\n',normXdiff/max(1,normX));
      fprintf(1,'\n');
   end
%%**********************************************************************
