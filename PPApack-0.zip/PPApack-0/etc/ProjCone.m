%%****************************************************************
%% projection onto a cone.
%%
%% [PX,PX0,type] = projCone(X,X0,cone_type,m1); 
%%
%% project [X0;X(1:m1)] onto the cone specified in cone_type;
%% for X(m1+1:end), there is no projection. 
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%****************************************************************


  function [PX,PX0,type] = projCone(X,X0,cone_type,m1); 

     len = length(X); 
     normX = norm(X); 
     normratio = abs(X0)/normX;
     if strcmp(cone_type,'u')
        PX = X; PX0 = X0; type = 'u'; 
     elseif strcmp(cone_type,'l')
        PX = max(0,X); PX0 = X0; type = 'l'; 
     elseif strcmp(cone_type,'q')
        if (normX <= abs(X0))   
           if (X0 >= 0); PX  = X; PX0 = X0; type = 'q1'; 
           else; PX = zeros(len,1); PX0 = 0; type = 'q3'; end
        else
           const = 0.5*(1+X0/normX); 
           PX = const*X; PX0 = const*normX; type = 'q2';
        end
     end
     %% fprintf('[%s]',type);
     if (len < m1) %% no projection
        PX(m1+1:end) = X(m1+1:end);             
     end
%%****************************************************************
