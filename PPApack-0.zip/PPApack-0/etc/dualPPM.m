%**********************************************************************
%% dualPPM: solve a nuclear norm minimization problem (NNM) by the 
%%          dual proximal point method where the subproblems are 
%%          solved by an accelerated proximal gradient method. 
%%
%%  (NNM) min { sum(svd(X)): norm(b1-A1(X)) <= delta, b2-A2(X) = 0 } 
%%
%%  where the scalar delta, the linear maps A1,A2,
%%  and the vectors b1,b2 are given.  
%%  The decision variable X is nrxnc matrix, not necessarily symmetric.
%%
%%  [X,iter,ttime,sd,runhist] = dualPPM(Amap,ATmap,bb,delta,nr,nc,m1,m2,par)
%%
%%  Input: 
%%  Amap  : evaluate the map A(X)   = [A1(X); A2(X)]
%%  ATmap : evaluate the map A^*(y) = [A1^*(y), A2^*(y)]
%%  bb    : [b1; b2]
%%  delta : a nonnegative scalar
%%  nr,nc : dimension of X
%%  m1    : length of b1 (=0 if b1 does not exist)
%%  m2    : length of b2 (=0 if b2 does not exist)
%%  par   : a structure array of parameters
%%
%%  Output:
%%  if X is numeric, then X = standard nrxnc matrix
%%  if X is a structure, then matrix = X.U*X.V';
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%**********************************************************************

   function [X,iter,ttime,sd,runhist] = dualPPM(Amap,ATmap,bb,delta,nr,nc,m1,m2,par)

   clear global  %% important 
   global X Xold Grad 

   if ~exist('par'); par = []; end
   nmin = min(nr,nc);
   randnstate = randn('state'); randstate = rand('state');
   randn('state',5); rand('state',5);
%%
   toltarget  = 1e-4;
   maxoutiter = 6;  
   maxsubiter = 30; 
   maxrank    = min(nmin,100); 
   verbose    = 1;
   plotyes    = 0;
   linesearch   = 1; 
   continuation = 1;
   truncation   = 1;
   truncation_gap = 5; 
 
   tstart = clock;
   if isfield(par,'tol'); toltarget = par.tol; end
   if isfield(par,'maxsubiter'); maxsubiter = par.maxsubiter; end
   if isfield(par,'maxoutiter'); maxoutiter = par.maxoutiter; end
   if isfield(par,'maxrank'); maxrank = par.maxrank; end
   if isfield(par,'verbose'); verbose = par.verbose; end
   if isfield(par,'plotyes'); plotyes = par.plotyes; end
   if isfield(par,'linesearch');   linesearch = par.linesearch; end   
   if isfield(par,'continuation'); continuation = par.continuation; end
   if isfield(par,'truncation');   truncation = par.truncation; end
   if isfield(par,'truncation_gap'); truncation_gap = par.truncation_gap; end
%%
   if ~isa(Amap,'function_handle') || ~isa(ATmap,'function_handle')
      error('Amap and ATmap must be function handles.');
   end
%%
   if (delta > 0)
      cone_type = 'q'; 
   else
      cone_type = 'u'; 
   end
%%
%% initial mu and target mu
%%
   svds_options.tol = 1e-6;    
   Grad = ATmap(bb); 
   maxsvdAtb = svds(Grad,1,'L',svds_options); maxsvdAtb = full(maxsvdAtb); 
   const_mu  = 1e-4;  
   mutarget  = const_mu*maxsvdAtb;
   if (~continuation)
      mu = mutarget; 
   else 
      mu = 1e3*mutarget;
   end
%%
%% estimate Lipschitz constant = largest eigenvalue of Amap(ATmap). 
%%
   mm = length(bb); 
   if (mm ~= m1+m2)
      error('dimension of b should be m1+m2');
   end
   AAT_is_identity = 0; 
   AX = randn(mm,1);
   AY = Amap(ATmap(AX)); 
   if (norm(AX-AY) < 1e-16*norm(AX)); 
      AAT_is_identity = 1; 
      Lipschitz_const = 1; 
   end
   if (AAT_is_identity==0)
      options.tol   = 1e-6; 
      options.issym = true; 
      options.disp  = 0; 
      options.v0    = randn(mm,1);
      Lipschitz_const = eigs(@(y)Amap(ATmap(y)),mm,1,'LM',options); 
      Lipschitz_const = full(Lipschitz_const); 
   end
%%
%% Initialization
%%
   svp = 5; 
   sv  = svp; 
   if (max(nr,nc) < 1000);  
      matrix_format = 'standard'; 
   else
      matrix_format = 'factors';       
   end 
   if (nmin <= 1000)
      fullsvdswitch = 200;
   else
      fullsvdswitch = max(floor(nmin/10)+100,200);
   end
   if (verbose); 
      fprintf('\n\n  nr = %2.0d, nc = %2.0d, m = %2.0d',nr,nc,mm); 
      fprintf('\n  maxsvdAtb   = %3.2e',maxsvdAtb); 
      fprintf('\n  mu_target   = %3.2e',mutarget); 
      fprintf('\n  Lipschitz const = %3.2e',Lipschitz_const);  
      fprintf('\n  matrix storage format = %s',matrix_format); 
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------'); 
      fprintf('\n            dual PPM')
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------'); 
      fprintf('\n   it     mu       tau      svp    relRd    relb_AX '); 
      fprintf(' relObjdiff     obj      '); 
      if (verbose == 2) 
         fprintf(' <tolsub>    time');
      else
         fprintf('time');
      end
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------');  
   end   
%%
   if strcmp(matrix_format,'standard')
      X = sparse(nr,nc); 
   else
      X.U = sparse(nr,1); X.V = sparse(nc,1);
   end
   Xold = X;
   AX = sparse(mm,1); 
   AXold = AX;
   normb = max(norm(bb,'fro'),1); 
   obj   = 0;
   normX = 0;  
   normXold = 0; 
   zz = sparse(mm,1); %% dual multiplier
   z0 = 0; 
   b_AX = bb-AX; 
   normRp = norm(b_AX); 
   maxsvdAtz = maxsvdAtb; 
%%
   runhist = struct('obj',[],'objlinesearch',[],'relRd',[],...
                    'relObjdiff',[],'relb_AX',[],'tau',[],'mu',[],...
	            'svp',[],'sv',[]);
   param.nr   = nr; 
   param.nc   = nc; 
   param.verbose    = verbose; 
   param.plotyes    = plotyes; 
   param.maxrank    = maxrank; 
   param.truncation = truncation; 
   param.fullsvdswitch = fullsvdswitch; 
%%
%%---------------------------------------------
%% main
%%---------------------------------------------
%%
   for outiter = 1:maxoutiter

      normb_AX = norm(b_AX); 
      if (delta==0)
         b0 = 0;
      else
         b0 = normb_AX; 
      end
      taumax = Lipschitz_const; 
      taumin = 1e-3*Lipschitz_const; 
      if (outiter == 1); 
         tau = taumax;
         maxsubitertmp = 10; %% important
      else
         maxsubitertmp = min(maxsubiter,outiter*5);
      end
      msg = '';
      breakyes  = 0; 
      fprintf('\n outiter = %d, norm(b-AX) = %3.2e',outiter,normb_AX);
      %%---------------------------------------------
      %% solve inner subproblem
      %%---------------------------------------------
      clear subhist; 
      for iter = 1:maxsubitertmp
%%
         tolsub = max(min(10,0.5*mu),min([1,0.02*normRp]));
         if (iter == 1) 
            t     = 1;
            beta1 = 1; 
            beta2 = 0; 
            AY = AX; 
         else
            t     = (1+sqrt(1+4*told^2))/2; 
            beta  = (told-1)/t; 
            beta1 = (1+beta); 
            beta2 = beta; 
            AY    = beta1*AX -beta2*AXold; 
         end
         [Gradvec,G0] = ProjCone(bb-AY+mu*zz,b0+mu*z0,cone_type,m1); 
         Gradvec = -Gradvec; %% remember the minus
	     Grad = ATmap(Gradvec); 
         fY = 0.5*(norm(Gradvec)^2 + G0^2);
         %%
         %% G = Y-Grad/tau, where Y = beta1*X-beta2*Xold. 
         %%
         normGrad = norm(Grad,'fro'); 
         if strcmp(matrix_format,'standard')
            trXXold = sum(sum(X.*Xold)); 
         else
            trXXold = sum(sum((Xold.U'*X.U).*(Xold.V'*X.V)));
         end
         trXGrad    = AX'*Gradvec;
         trXoldGrad = AXold'*Gradvec;
         normY2  = beta1^2*normX^2 + beta2^2*normXold^2 -2*beta1*beta2*trXXold;
         trYGrad = beta1*trXGrad - beta2*trXoldGrad;
         normG2  = normY2 - (2/tau)*trYGrad + (1/tau^2)*normGrad^2;  
         %%
         %% pre-determine the number of singular values to compute
         %% and singular value thresholding.
         %%
         if (svp == sv) && (iter > 10 || outiter > 1) %% important
            sv = min(svp+5,nmin); 
         else
            sv = min(svp+1,nmin);
         end
         if (mu > mutarget);
            svdtol = min(1e-2,0.01*mu);  
         else
            svdtol = min(0.1*tolsub,0.01*mu); 
         end
         param.matrix_format = matrix_format; 
         param.beta1 = beta1; param.beta2 = beta2; param.beta3 = 1/tau; 
         if (iter <= 5) && (outiter == 1); 
            gap = inf; 
         else
            gap = truncation_gap; 
         end
         [U,V,sd,svp] = proxmap(sv,1,mu/tau,svdtol,gap,param);          
         %%
         if strcmp(matrix_format,'standard')
            trXnewX    = sum(sum(U.*(X*V)));
            trXnewXold = sum(sum(U.*(Xold*V)));             
         else
            trXnewX    = sum(sum((X.U'*U).*(X.V'*V)));
            trXnewXold = sum(sum((Xold.U'*U).*(Xold.V'*V)));
         end
         told     = t;      
         normXold = normX; 
         objold   = obj;    
         AXold    = AX;            
         %%
         Xold = X;         
	     if strcmp(matrix_format,'standard');
             X = U*V';  
         else
             X.U = U; X.V = V; 
         end
         AX = Amap(X); 
         trXnewGrad = AX'*Gradvec; 
         trXnewY = beta1*trXnewX - beta2*trXnewXold; 
         trXnewG = trXnewY - (1/tau)*trXnewGrad;      
         normXG2 = norm(sd)^2 + normG2 - 2*trXnewG; 
         objlinesearch = fY -normGrad^2/(2*tau) +(tau/2)*normXG2;
         objlinesearch = objlinesearch/mu + sum(sd); 
         %%
         b_AX   = bb-AX;
         [ztmp,ztmp0] = ProjCone(zz+(1/mu)*b_AX,z0+(1/mu)*b0,cone_type,m1); 
         fX     = 0.5*mu*(norm(ztmp)^2 +ztmp0^2);
         obj    = fX + sum(sd);
         normXnew = norm(sd,'fro');
         normX_Y  = sqrt(normXnew^2 +normY2 -2*trXnewY); 
         AX_AY = AX-AY; 
         normX = norm(sd); 
         normS_options = 1; 
         if (normS_options == 1)
            Gradvec = ztmp+Gradvec/mu; 
            if (AAT_is_identity)
               normtmp = norm(Gradvec,'fro'); 
            else
               normtmp = norm(ATmap(Gradvec),'fro'); 
            end
            normS2 = tau^2*normX_Y^2 +normtmp^2 +2*tau*(Gradvec'*(AX_AY));
            normS2 = mu^2*normS2; 
            if (normS2 < 0); error('normS2 < 0'); end           
	     else
            if (AAT_is_identity)
               normS2 = tau^2*normX_Y^2 + (1-2*tau)*norm(AX_AY)^2; 
            else
               normtmp = norm(ATmap(AX_AY),'fro'); 
               normS2 = tau^2*normX_Y^2 -2*tau*norm(AX_AY)^2 +normtmp^2; 
            end
         end
         relRd      = sqrt(normS2); 
         relb_AX    = norm(b_AX)/normb; 
         relObjdiff = abs(obj-objold)/max(1,obj);  
         subhist.obj(iter)           = obj; 
         subhist.objlinesearch(iter) = objlinesearch; 
         subhist.relRd(iter)         = relRd;
         subhist.relObjdiff(iter)    = relObjdiff;  
         subhist.relb_AX(iter)       = relb_AX;  
         subhist.tau(iter)           = tau;
         subhist.mu(iter)            = mu; 
         subhist.svp(iter)           = svp; 
         subhist.sv(iter)            = sv; 
         %%
         if (verbose)
            fprintf('\n   %2.0d  %3.2e %3.2e |%3.0d %3.0d| ',iter,mu,tau,svp,sv);
	        fprintf('%3.2e %3.2e| %3.2e %5.4e|',relRd,relb_AX,relObjdiff,obj); 
            if (verbose==2); fprintf(' <%3.2e>',tolsub); end
         end    	  
         %% 
         %% check stopping criterion
         %%
	     if (outiter > 1) && (iter > 1)
             if (max([relRd, 0.1*relObjdiff]) < tolsub)
                 msg = sprintf('relRd < tolsub = %3.2e',tolsub);
                 if (verbose==2); fprintf('<a>'); end
                 breakyes=1; 
             end
	         if (relRd < min(1,5*tolsub)) && (relObjdiff < min(1e-5,tolsub/100))
                 msg = sprintf('relObjdiff < relObjdiff_tol');
                 if (verbose==2); fprintf('<b>'); end
                 breakyes=1;
             end
             idx = [max(2,iter-2):iter];
             ratio = subhist.relb_AX(idx-1)./subhist.relb_AX(idx); 
             if (iter > 3) && (relRd < min(1,10*tolsub)) && ...
                     (all(abs(ratio-1) < min(0.1,5*tolsub)))
                 msg = sprintf('lack of progress in relb_AX : %2.1e',max(ratio-1));
                 if (verbose==2); fprintf('<c>'); end
                 breakyes=1; 
             end
             if (breakyes); fprintf('\n %s',msg); break; end
         end
         %%
         %% perform linesearch to update tau. 
         %% 
         if (linesearch)
            if (verbose==2); fprintf(' %5.4e|',objlinesearch); end
            const_eta = 0.8; 
            if (obj < objlinesearch)
                tau = min(taumax,max(const_eta*tau,taumin)); 
            else
               %% restart using old X. 
               X      = Xold;   
 	           told   = 1; 
               AX     = AXold; 
               normX  = normXold;
               taumin = tau/const_eta; 
               tau    = min(tau/const_eta,taumax); 
            end
   	        if (iter > 4)
                idx = [iter-4:iter]; 
                if all(subhist.obj(idx) < 0.98*subhist.objlinesearch(idx))
                    taumin = taumin*const_eta; 
                end
            end
         end
         if (verbose); fprintf(' %3.2e|',etime(clock,tstart)); end
      end
      %%---------------------------------------------
      %% end of inner subproblem
      %%---------------------------------------------
      update_dual = 1;
      if (update_dual)
         [ztmp,ztmp0] = ProjCone(zz+(1/mu)*b_AX,z0+(1/mu)*b0,cone_type,m1); 
         Grad = ATmap(ztmp);  
         maxsvdAtz = svds(Grad,1,'L'); maxsvdAtz = full(maxsvdAtz);  
         ztmp  = ztmp/max(1,maxsvdAtz); %% better
         ztmp0 = ztmp0/max(1,maxsvdAtz); 
         normRp = mu*sqrt(norm(ztmp-zz)^2 +(ztmp0-z0)^2); 
         relRp  = normRp/normb; 
         zz = ztmp;
         z0 = ztmp0;
         if (continuation) 
            mu = max(0.1*mu,mutarget);  %% must be after zz 
         end
         fprintf('\n updated zz: maxsvd(Atz) = %3.2e, ',maxsvdAtz); 
         fprintf('Rp = %3.2e, relRp = %3.2e\n',normRp,relRp); 
         runhist.obj           = [runhist.obj, subhist.obj]; 
         runhist.objlinesearch = [runhist.objlinesearch, subhist.objlinesearch];
         runhist.relRd         = [runhist.relRd, subhist.relRd];
         runhist.relObjdiff    = [runhist.relObjdiff, subhist.relObjdiff];
         runhist.relb_AX       = [runhist.relb_AX, subhist.relb_AX];
         runhist.tau   = [runhist.tau, subhist.tau]; 
         runhist.mu    = [runhist.mu, subhist.mu]; 
         runhist.svp   = [runhist.svp, subhist.svp]; 
         runhist.sv    = [runhist.sv, subhist.sv]; 
         runhist.iter(outiter)  = iter; 
         runhist.relRp(outiter) = relRp; 
         if (relRp < toltarget) && (mu == mutarget)
            msg = sprintf('relRp < toltarget = %3.2e',toltarget); 
            fprintf(' ********** %s\n',msg);
            break; 
         end
      end
   end 
   sinmax = max(sd);
   sinmin = min(sd(sd>0));
   ttime  = etime(clock,tstart);
%%
%% Print results
%%
   iter = sum(runhist.iter); 
   if (verbose)
      fprintf(1,'\n Finished the main algorithm!\n')
      fprintf(1,' Objective function        = %6.5e\n',obj);
      fprintf(1,' Number of iterations      = %2.0d\n',iter);
      fprintf(1,' Number of singular values = %2.0d\n',svp);
      fprintf(1,' max singular value        = %3.2e\n',sinmax);
      fprintf(1,' min singular value        = %3.2e\n',sinmin);
      fprintf(1,' CPU time                  = %3.2e\n',ttime);
      fprintf(1,' norm(X-Xold,''fro'')/norm(X,''fro'') = %3.2e',relRd);
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------'); 
      fprintf(1,'\n');
   end
%%**********************************************************************

