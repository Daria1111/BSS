%%**************************************************
%% compute A*z for 
%% A = beta1*X - beta2*Xold - beta3*Grad;
%% 
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%**************************************************

  function Az = matvec_PP(z,param) 

  global X Xold Grad 

  beta1 = param.beta1; 
  beta2 = param.beta2; 
  beta3 = param.beta3; 
  nr = param.nr; 
  nc = param.nc;
  tol   = 1e-16;  
%%
  z1 = X.U*(X.V'*z);
  if (abs(beta2) > tol)
     z2 = Xold.U*(Xold.V'*z);
  else 
     z2 = sparse(nr,1); 
  end
  if (abs(beta3) > tol)    
     Gz = mexMatvec(Grad,z); 
     %% Gz = Grad*z; 
  else
     Gz = sparse(nr,1); 
  end
  Az = beta1*z1 -beta2*z2 -beta3*Gz; 
%%**************************************************
