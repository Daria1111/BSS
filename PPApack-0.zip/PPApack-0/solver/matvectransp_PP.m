%%**************************************************
%% compute AT*z for 
%% A = beta1*X - beta2*Xold - beta3*Grad;
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh 
%%**************************************************

  function ATz = matvectransp_PP(z,param)

  global X Xold Grad

  beta1 = param.beta1; 
  beta2 = param.beta2; 
  beta3 = param.beta3; 
  nr = param.nr; 
  nc = param.nc; 
  tol = 1e-16; 
%%
  z1  = X.V*(X.U'*z); 
  if (abs(beta2) > tol)
     z2  = Xold.V*(Xold.U'*z); 
  else
     z2 = sparse(nc,1); 
  end
  if (abs(beta3) > tol); 
     GTz = mexMatvec(Grad,z,1); 
     %% GTz = (z'*Grad)'; 
  else
     GTz = sparse(nc,1); 
  end
  ATz = beta1*z1 -beta2*z2 -beta3*GTz; 
%%**************************************************
