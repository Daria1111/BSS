%%**********************************************************************
%%
%% Input: X is a matrix, or a structure containing the factors U,V. 
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%**********************************************************************

   function xx = Amap_RKE(X,blk,At); 

   if isnumeric(X) 
      xx = (mexsvec(blk,X)'*At)'; 
   elseif isstruct(X)
      xx = (mexsvec(blk,X.U*X.V')'*At)';       
   end
%%**********************************************************************

