%%**********************************************************************
%% find the vector x, where x(1)= sum(sum(X))/const and x(2:end) is obtained 
%% from the matrix X = U*V' by extracting the entries with indices 
%% specified in (II,Jcol), which is in compressed sparse column format. 
%%
%% Input: X is a matrix, or a structure containing the factors U,V. 
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%**********************************************************************

  function xx = Amap_MaxClique(X,II,Jcol,const)

  nn  = length(II);
  len = nn+1; 
  xx  = zeros(len,1);

  if isnumeric(X)
     if (size(X,1) ~= size(X,2))
        error('X must be square');
     else
        xx(1) = sum(sum(X))/const;
     end
  else
     if (size(X.U,1) ~= size(X.V,1))
        error('X must be square');
     else
        e = ones(size(X.U,1),1); 
        u = X.U'*e; v = X.V'*e;
        xx(1) = u'*v/const; 
     end
  end
  xx(2:end) = Amap_MatComp(X,II,Jcol);
%%**********************************************************************
