%%****************************************************************
%% projection onto a cone.
%%
%% [PX0,PX] = ProjCone(X0,X,param); 
%%
%% project [X0;X(1:m1)] onto the second order cone if m1 > 0;
%% project [X(m1+1:m1+m2)] onto the first orthant if m2 > 0;  
%% for [X(m1+m2+1:end)], there is no projection.
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%****************************************************************


  function [PX0,PX] = ProjCone(X0,X,param) 

     m1 = param.m1;
     m2 = param.m2;
     m3 = param.m3;
  
     if (min(size(X)) > 1)
        error('X must be a vector');
     elseif (size(X,2) > 1)
        X = X';
     end
     len = length(X); 
     PX  = zeros(len,1);
     if (m1 > 0)
        [PX0,PX(1:m1)] = ProjSoc(X0,X(1:m1)); 
     else
        PX0 = X0;
     end
     if (m2 > 0)
        PX(m1+1:m1+m2) = max(0,X(m1+1:m1+m2));
     end
     if (m3 > 0)
        PX(m1+m2+1:end) = X(m1+m2+1:end);
     end
%%****************************************************************

      function [PX0,PX] = ProjSoc(X0,X)
          
          len   = length(X);
          normX = norm(X);
          if (normX <= abs(X0))
             if (X0 >= 0) 
                PX0 = X0;  PX  = X;
             else
                PX0 = 0;  PX = zeros(len,1); 
             end
          else
             const = 0.5*(1+X0/normX); 
             PX0 = const*normX; PX = const*X; 
          end
%%*****************************************************************
