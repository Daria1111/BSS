%%******************************************************************
%% proxmap: solve 
%%          min { (0.5/rho)*norm(X-H,'fro')^2 + ||X||_* }
%%
%% H = beta1*X - beta2*Xold - beta3*Grad. 
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%******************************************************************

   function [U,V,sd,svp,res,d] = ...
             proxmap(sv,countmax,rho,svdtol,gap,param) 

   global X Xold Grad

   nr = param.nr; 
   nc = param.nc; 
   nmin = min(nr,nc); 
   verbose    = param.verbose; 
   plotyes    = param.plotyes;
   maxrank    = param.maxrank; 
   truncation = param.truncation; 
   matrix_format = param.matrix_format; 
   use_fullsvd   = param.use_fullsvd; 
%%
   if strcmp(matrix_format,'standard'); 
      HH = param.beta1*X - param.beta2*Xold - param.beta3*Grad; 
   end
%%
   count = 1; 
   while (count<=countmax) 
      lanpar.tol = svdtol; 
      if strcmp(matrix_format,'standard')
         if (use_fullsvd)
            [U,S,V] = mexsvd(full(HH),0);
            countmax = 1;
            res = sparse(nmin,1);  
         else
            [U,S,V,res] = lansvd(HH,sv,'L',lanpar);
         end
      else
         [U,S,V,res] = ...
         lansvd('matvec_PP','matvectransp_PP',nr,nc,sv,'L',lanpar,param);
      end
      d  = diag(S);
      sd = max(0,d-rho);
      %%
      %% estimate the rank 
      %%
      drho = d-rho; 
      ratio = drho(1:end-1)./drho(2:end);
idxstart = 1; %% 2009 Nov 14
      idxbig = find(abs(ratio(idxstart:end)) > gap);   
      if ~isempty(idxbig)
         idxtruncate = min((idxstart-1)+idxbig(1)+1,length(find(sd>0))); 
      else
         idxtruncate = length(find(sd>0)); 
      end
      normratio = zeros(1,idxtruncate); 
      window = 10; 
      for kk = idxstart:idxtruncate-1
         sd1 = drho(max(1,kk-window):kk); 
         sd2 = drho(kk+1:min(idxtruncate,kk+window+1)); 
         normratio(kk) = mean(sd1)/(mean(sd2)+eps); 
      end 
      [maxnormratio,maxidx] = max(abs(normratio));
      if (truncation)
         if (maxnormratio > gap) 
            sd = sd(1:maxidx); 
         end
      end
      sd = sd(1:min(length(find(sd > 0)),maxrank)); 
      if (plotyes); plotgraph(d,rho); end
      if (verbose == 2); fprintf(' [%3.2e]',maxnormratio); end
      %%
      %% there may be more singular values that are >= rho.
      %% So increase the predetermined number of singular values.
      %%
      svp = length(find(sd>0));
      if (svp < sv) || (svp == nmin); 
         break; 
      else
         count = count + 1; 
      end
   end 
   Shlf = spdiags(sqrt(sd),0,svp,svp); 
   U = full(U(:,1:svp)*Shlf); V = full(V(:,1:svp)*Shlf); 
   res = res(1:svp); 
%%******************************************************************
