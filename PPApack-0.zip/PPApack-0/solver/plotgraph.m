%%*************************************************
%% called in proxmap
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%*************************************************

   function plotgraph(d,cutoff); 

   subplot(121)
   semilogy([1,length(d)],cutoff*[1,1]); hold on;               
   semilogy([1,length(d)],1e1*cutoff*[1,1]);
   semilogy([1,length(d)],1e2*cutoff*[1,1]);
   semilogy(d,'*'); hold off;  

   subplot(122)
   ratio  = (d(1:end-1)-cutoff)./(d(2:end)-cutoff);
   plot(ratio,'*'); pause(0.01);
%%*************************************************
