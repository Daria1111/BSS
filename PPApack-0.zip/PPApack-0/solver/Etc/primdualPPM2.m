%%**********************************************************************
%% primdualPPM2: solve a nuclear norm minimization problem (NNM) by the 
%%          primal-dual (II) proximal point method where the subproblems are 
%%          solved by an accelerated proximal gradient method. 
%%
%%  (NNM) min { sum(svd(X)): A(X) \in b+Q } 
%%
%%  where the linear map A and the vector b are given. 
%%  The decision variable X is nrxnc matrix, not necessarily symmetric.
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%**********************************************************************

   function [X,iter,ttime,sd,runhist] = ...
                    primaldualPPM2(nr,nc,Amap,ATmap,bb,par)

   clear global  %% important 
   global X Xold Grad

   if ~exist('par'); par = []; end
   nmin = min(nr,nc);
   randnstate = randn('state'); randstate = rand('state');
   randn('state',5); rand('state',5);
%%
   toltarget  = 1e-4;
   maxoutiter = 6;  
   maxsubiter = 30; 
   maxrank    = min(nmin,100); 
   verbose    = 1;
   plotyes    = 0;
   linesearch   = 1; 
   continuation = 1; 
   truncation   = 1;
   truncation_gap = 5; 
   noiseratio   = 0; 
 
   tstart = clock;
   if isfield(par,'tol'); toltarget = par.tol; end
   if isfield(par,'maxsubiter'); maxsubiter = par.maxsubiter; end
   if isfield(par,'maxoutiter'); maxoutiter = par.maxoutiter; end
   if isfield(par,'maxrank'); maxrank = par.maxrank; end
   if isfield(par,'verbose'); verbose = par.verbose; end
   if isfield(par,'plotyes'); plotyes = par.plotyes; end
   if isfield(par,'linesearch');   linesearch = par.linesearch; end   
   if isfield(par,'continuation'); continuation = par.continuation; end
   if isfield(par,'truncation');   truncation = par.truncation; end
   if isfield(par,'truncation_gap'); truncation_gap = par.truncation_gap; end
   if isfield(par,'noiseratio');   noiseratio = par.noiseratio; end
%%
   if ~isa(Amap,'function_handle') | ~isa(ATmap,'function_handle')
      error(['Amap and ATmap must be function handles.']);
   end
   param.nr   = nr; 
   param.nc   = nc; 
   param.verbose    = verbose; 
   param.plotyes    = plotyes; 
   param.maxrank    = maxrank; 
   param.truncation = truncation; 
%%
%% initial mu and target mu
%%
   svds_options.tol = 1e-6;    
   Grad = ATmap(bb); 
   maxsvdAtb = svds(Grad,1,'L',svds_options); maxsvdAtb = full(maxsvdAtb); 
   const_mu  = 1e-4;  
   mutarget  = const_mu*maxsvdAtb;
   if (~continuation)
      mu = mutarget; 
   else 
      mu = 1e3*mutarget;
   end
%%
%% estimate Lipschitz constant = largest eigenvalue of Amap(ATmap). 
%%
   mm = length(bb); 
   AAT_is_identity = 0; 
   AX = randn(mm,1);
   AY = Amap(ATmap(AX)); 
   if (norm(AX-AY) < 1e-16*norm(AX)); 
      AAT_is_identity = 1; 
      Lipschitz_const = 1; 
   end
   if (AAT_is_identity==0)
      options.tol   = 1e-6; 
      options.issym = true; 
      options.disp  = 0; 
      options.v0    = randn(mm,1);
      Lipschitz_const = eigs(@(y)Amap(ATmap(y)),mm,1,'LM',options); 
      Lipschitz_const = full(Lipschitz_const); 
   end
%%
%% Initialization
%%
   svp = 5; 
   sv  = svp; 
   if (max(nr,nc) < 1000);  
      matrix_format = 'standard'; 
   else
      matrix_format = 'factors'; 
   end   
   if (nmin <= 1000)
      fullsvdtol = 200;
   else
      fullsvdtol = max(floor(nmin/10)+100,200);
   end
   if (verbose); 
      fprintf('\n\n  nr = %2.0d, nc = %2.0d, m = %2.0d',nr,nc,mm); 
      fprintf('\n  maxsvdAtb   = %3.2e',maxsvdAtb); 
      fprintf('\n  mu_target   = %3.2e',mutarget); 
      fprintf('\n  Lipschitz const = %3.2e',Lipschitz_const);  
      fprintf('\n  matrix storage format = %s',matrix_format); 
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------'); 
      fprintf('\n   it     mu       tau      svp    relRd    relb_AX '); 
      fprintf(' relObjdiff    obj      <tolsub>    time')
      fprintf('\n-----------------------------------------------');
      fprintf('-------------------------------------------');  
   end   
%%
   X.U = sparse(nr,1); X.V = sparse(nc,1);
   Xold = X;
   AX = sparse(mm,1); 
   AXold = AX;
   normb = max(norm(bb,'fro'),1); 
   obj   = 0;
   normX = 0;  
   normXold = 0; 
   zz   = sparse(mm,1); %% dual multiplier
   z0   = 0; 
   b_AX = bb-AX; 
   normRp = norm(b_AX);
   maxsvdAtz = maxsvdAtb;
%%
   if (noiseratio > 0)
      cone_type = 'q'; 
   else
      cone_type = 'u'; 
   end
%%
%%---------------------------------------------
%% main
%%---------------------------------------------
%%
   for outiter = 1:maxoutiter

      normb_AX = norm(b_AX); 
      if (noiseratio==0)
         b0 = 0;
      else
         b0 = normb_AX; 
      end
      const_eta = 0.8; 
      taumax = Lipschitz_const; 
      taumin = 1e-3*Lipschitz_const; 
      if (outiter == 1); 
         normRp    = normb_AX; 
         maxsvdAtz = maxsvdAtb; 
         tau       = taumax;
         maxsubitertmp = 10; %% important
      else
         maxsubitertmp = min(maxsubiter,outiter*5);
      end
      muhat    = min(1e-2,0.1*mu); 
      breakyes = 0; 
      msg      = '';
      fprintf('\n outiter = %d, norm(b-AX) = %3.2e',outiter,normb_AX);
      %%---------------------------------------------
      %% solve inner subproblem
      %%---------------------------------------------
      clear subhist; 
      for iter = 1:maxsubitertmp
%%
         tolsub = max(min(10,0.5*mu),min([1,0.02*normRp]));
         if (iter == 1) 
            t     = 1;
            beta1 = 1; 
            beta2 = 0; 
            AY = AX; 
         else
            t     = (1+sqrt(1+4*told^2))/2; 
            beta  = (told-1)/t; 
            beta1 = (1+beta); 
            beta2 = beta; 
            AY    = beta1*AX -beta2*AXold; 
         end
         [Gradvec,G0] = ProjCone(bb-AY+mu*zz,b0+mu*z0,cone_type); 
         Gradvec = -Gradvec; %% remember the minus sign.
	 Grad = ATmap(Gradvec); 
         fY = 0.5*(norm(Gradvec)^2 + G0^2);
         %%
         beta1org = beta1; 
         beta2org = beta2; 
         if (mu < 1); add_normXdiff = 1; else; add_normXdiff = 0; end
         if (add_normXdiff)
            tmpconst = mu*muhat/tau; 
   	    beta1 = (1-tmpconst)*beta1org + tmpconst; 
            beta2 = (1-tmpconst)*beta2org; 
         end
         %%
         %% G = Y-Grad/tau, where Y = beta1*X-beta2*Xold. 
         %%
         normGrad = norm(Grad,'fro'); 
         trXXold    = sum(sum((Xold.U'*X.U).*(Xold.V'*X.V)));
         trXGrad    = AX'*Gradvec;
         trXoldGrad = AXold'*Gradvec;
         normY2  = beta1^2*normX^2 +beta2^2*normXold^2 -2*beta1*beta2*trXXold;
         trYGrad = beta1*trXGrad - beta2*trXoldGrad;
         normG2  = normY2 - (2/tau)*trYGrad + (1/tau^2)*normGrad^2;  
         normYorg2  = beta1org^2*normX^2 + beta2org^2*normXold^2 ...
                      - 2*beta1org*beta2org*trXXold;
         trYorgGrad = beta1org*trXGrad - beta2org*trXoldGrad;
         %%
         %% pre-determine the number of singular values to compute
         %% and singular value thresholding.
         %%
         if (svp == sv) & (iter > 10 | outiter > 1) %% important
            sv = min(svp+5,nmin); 
         else
            sv = min(svp+1,nmin);
         end
         countmax = 1; 
         if (mu > mutarget);
            svdtol = min([1e-4,0.01*mu]);  
         else
            svdtol = min([1e-6,0.1*tolsub,0.01*mu]); 
         end
         if (iter <= 5) & (outiter == 1); 
            gap = inf; 
         else
            gap = truncation_gap; 
         end
         param.matrix_format = matrix_format; 
         param.beta1 = beta1; param.beta2 = beta2; param.beta3 = 1/tau;
         if (iter > 1); param.verbose = 1; else; param.verbose = 0; end
         [U,V,sd,svp] = proxmap(sv,1,mu/tau,svdtol,gap,param); 
         %%
         trXnewX    = sum(sum((X.U'*U).*(X.V'*V)));
         trXnewXold = sum(sum((Xold.U'*U).*(Xold.V'*V)));
         told     = t;      
         normXold = normX; 
         objold   = obj;    
         AXold    = AX; 
         %%
         Xold = X; 
	 X.U  = U; X.V = V; 
         %% must be after AXold = AX; 
         AX = Amap(X); 
         normXnew2   = norm(sd)^2;      
         trXnewY     = beta1*trXnewX - beta2*trXnewXold; 
         normXnew_Y2 = normXnew2 + normY2 - 2*trXnewY; 
         trXnewGrad  = AX'*Gradvec; 
         trXnewG     = trXnewY - (1/tau)*trXnewGrad; 
         normXnew_G2 = normXnew2 + normG2 - 2*trXnewG; 
         trXnewYorg  = beta1org*trXnewX - beta2org*trXnewXold; 
         normXnew_Yorg2 = normXnew2 + normYorg2 - 2*trXnewYorg; 
         trXYorg     = beta1org*normX^2 - beta2org*trXXold; 
         normX_Yorg2 = normX^2 + normYorg2 - 2*trXYorg; 
         if (add_normXdiff); 
            fY = fY + 0.5*mu*muhat*normX_Yorg2; 
            normGrad2 = normGrad^2 + 2*mu*muhat*(trYorgGrad-trXGrad) ...
                        + (mu*muhat)^2*normX_Yorg2; 
         else
            normGrad2 = normGrad^2; 
         end
         objlinesearch = fY -normGrad2/(2*tau) +(tau/2)*normXnew_G2;
         objlinesearch = objlinesearch/mu + sum(sd); 
         %%
         normX = norm(sd); 
         b_AX = bb-AX;
         normXnew_X2  = normXnew2 + normX^2 - 2*trXnewX; 
         [ztmp,ztmp0] = ProjCone(zz+(1/mu)*b_AX,z0+(1/mu)*b0,cone_type); 
         fX  = 0.5*mu*(norm(ztmp)^2 +ztmp0^2);
         if (add_normXdiff); 
            fX = fX + 0.5*muhat*normXnew_X2; 
         end
         obj = fX + sum(sd); 
         if (add_normXdiff); taumod = tau - mu*muhat; else; taumod = tau; end
         AX_AY = AX-AY; 
         normS_options = 1; 
         if (normS_options == 1)
            Gradvec = ztmp + Gradvec/mu; 
            if (AAT_is_identity)
               normtmp = norm(Gradvec); 
            else
               normtmp = norm(ATmap(Gradvec)); 
            end
            normS2 = taumod^2*normXnew_Yorg2 +normtmp^2 +2*taumod*(Gradvec'*(AX_AY)); 
            if (normS2 < 0); error('normS2 < 0'); end
            normS2 = mu^2*normS2;  
         end
         relRd      = sqrt(normS2); 
         relb_AX    = norm(b_AX)/normb; 
         relObjdiff = abs(obj-objold)/max(1,obj);  
         subhist.obj(iter)           = obj; 
         subhist.objlinesearch(iter) = objlinesearch; 
         subhist.relRd(iter)         = relRd;
         subhist.relObjdiff(iter)    = relObjdiff;  
         subhist.relb_AX(iter)       = relb_AX;  
         subhist.tau(iter)           = tau;
         subhist.mu(iter)            = mu; 
         subhist.svp(iter)           = svp; 
         subhist.sv(iter)            = sv; 
         %%
         if (verbose)
            fprintf('\n   %2.0d  %3.2e %3.2e |%3.0d %3.0d| ',...
                     iter,mu,tau,svp,sv);
	    fprintf('%3.2e %3.2e %3.2e| %- 5.4e %- 5.4e|',...
                     relRd,relb_AX,relObjdiff,obj,objlinesearch); 
            fprintf(' <%3.2e>',tolsub);
         end    	  
         %% 
         %% check stopping criterion
         %%
	 if (outiter > 1) & (iter > 1) 
            if (max([relRd, 0.1*relObjdiff]) < tolsub) 
    	       msg = sprintf('relRd < tolsub = %3.2e',tolsub);
               fprintf('<a>'); 
               breakyes=1; 
            end
	    if (relRd < min(1,5*tolsub)) & (relObjdiff < min(1e-5,tolsub/100)) 
   	       msg = sprintf('relObjdiff < relObjdiff_tol');
               fprintf('<b>'); 
               breakyes=1;
            end
            idx = [max(2,iter-2):iter];
            ratio = subhist.relb_AX(idx-1)./subhist.relb_AX(idx); 
            if (iter > 3) & (relRd < min(1,10*tolsub)) & ...
	       (all(abs(ratio-1) < min(0.1,5*tolsub)))  
   	       msg = sprintf('no progress in relb_AX: %2.1e',max(ratio-1));
               fprintf('<c>'); 
               breakyes=1; 
            end
            if (breakyes); fprintf('\n %s',msg); break; end
         end
         %%
         %% perform linesearch to update tau. 
         %% 
         if (linesearch)
            if (obj < objlinesearch) 
   	       tau = min(taumax,max(const_eta*tau,taumin)); 
            else
               %% restart using old X. 
               X = Xold;   
 	       told   = 1; 
               AX     = AXold; 
               normX  = normXold;
               taumin = tau/const_eta; 
               tau    = min(tau/const_eta,taumax); 
            end
   	    if (iter > 4) 
               idx = [iter-4:iter]; 
               if all(subhist.obj(idx) < 0.98*subhist.objlinesearch(idx))
                  taumin = taumin*const_eta; 
               end
            end
         end
         if (verbose); fprintf(' %3.2e|',etime(clock,tstart)); end
      end
      %%---------------------------------------------
      %% end of inner subproblem
      %%---------------------------------------------
      update_dual = 1;
      if (update_dual)
         timetmp = clock; 
         [ztmp,ztmp0] = ProjCone(zz+(1/mu)*b_AX,z0+(1/mu)*b0,cone_type); 
         Grad = ATmap(ztmp); 
         svdAtz = svds(Grad,1,'L'); maxsvdAtz = full(max(diag(svdAtz)));  
         ztmp   = ztmp/max(1,maxsvdAtz); %% better
         ztmp0  = ztmp0/max(1,maxsvdAtz); 
         normRp = mu*sqrt(norm(ztmp-zz)^2 +(ztmp0-z0)^2); 
         relRp  = normRp/normb; 
         zz = ztmp;
         z0 = ztmp0;
         if (continuation)
            mu = max(0.1*mu,mutarget);  %% must be after zz 
         end
         fprintf('\n compute maxsvdAtz time = %3.2e',etime(clock,timetmp)); 
         fprintf('\n updated zz: maxsvd(Atz) = %3.2e, ',maxsvdAtz); 
         fprintf('Rp = %3.2e, relRp = %3.2e\n',normRp,relRp); 
         runhist.obj(outiter)     = obj;
         runhist.relRd(outiter)   = relRd;
         runhist.relb_AX(outiter) = relb_AX;
         runhist.mu(outiter)      = mu; 
         runhist.svp(outiter)     = svp; 
         runhist.sv(outiter)      = sv;
         runhist.iter(outiter)    = iter; 
         runhist.relRp(outiter)   = relRp; 
         if (relRp < toltarget) & (mu == mutarget) & (relRd < 1)
            msg = sprintf('relRp < toltarget = %3.2e',toltarget); 
            fprintf(' ********** %s\n',msg);
            break; 
         end
      end
   end 
   sinmax = max(sd);
   sinmin = min(sd(find(sd>0)));
   ttime  = etime(clock,tstart);
%%
%% Print results
%%
   iter = sum(runhist.iter); 
   if (verbose)
      fprintf(1,'\n Finished the main algorithm!\n')
      fprintf(1,' Objective function        = %6.5e\n',obj);
      fprintf(1,' Number of iterations      = %2.0d\n',iter);
      fprintf(1,' Number of singular values = %2.0d\n',svp);
      fprintf(1,' max singular value        = %3.2e\n',sinmax);
      fprintf(1,' min singular value        = %3.2e\n',sinmin);
      fprintf(1,' CPU time                  = %3.2e\n',ttime);
      fprintf(1,' norm(X-Xold,''fro'')/norm(X,''fro'') = %3.2e\n',relRd);
      fprintf(1,'\n');
   end
%%**********************************************************************

