%%**********************************************************************
%% ATmap_MaxClique(y,II,Jcol,n,const): Compute Aty 
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh
%%**********************************************************************

  function Aty = ATmap_MaxClique(y,II,Jcol,n,const)

  y   = full(y);
  Aty = mexspconvert(n,n,y(2:end),II,Jcol);
  Aty = Aty + y(1)/const;
%%**********************************************************************
