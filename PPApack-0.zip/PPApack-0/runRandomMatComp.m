%%************************************************************************
%% run random matrix completion problems. 
%% 
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh 
%%************************************************************************

  clear all; 
  warning off; 
%%
  addpath('PROPACKmod');
  addpath('solver');
%%
%% generate random a test problem 
%% n = size of the unknown square matrix M, r = rank of M
%%
  ndim  = [1e3, 1e3, 1e3, 5e3, 5e3, 5e3, 1e4, 1e4, 1e4, 2e4, 3e4, 5e4, 1e5];
  rrank = [10,  50,  100, 10,  50,  100, 10,  50,  100, 10,  10,  10,  10]; 
  pfac  = [6,   4,   3,   6,   5,   4,   6,   5,   4,   6,   6,   6,   6];
%%
  method = 'dualPPA'; 'primPPA'; 
  scenario = 'noisy'; 'noiseless';  
  randstate_idx = [1]; 
%%
  for kk = [1]; 
      r  = rrank(kk); 
      cp = pfac(kk); 
      n  = ndim(kk);
      nr = n; nc = n;  
      if strcmp(scenario,'noiseless'); 
         noiseratio = 0; 
      else
         noiseratio = 0.1;        
      end
      for randstate = [randstate_idx];   
         fprintf('\n Create matrix %2.0d with rank = %2.0d,',randstate,r); 
         dr = r*(nr+nc-r);
         p  = cp*dr; %% number of sampled entries    
         randn('state',randstate);
         rand('state',randstate);
         %% construct M (nxn), Omega (nxn)
         %% M = M.U*M.V';
         %% Omega = spconvert([II,JJ,ones(p,1); n,n,0]); 
         %% B = M.*Omega;         
         M.U = randn(nr,r); 
         M.V = randn(nc,r); 
         prob = p/(nr*nc); 
         II = zeros(p,1); JJ = zeros(p,1); cnt = 0; 
         for j=1:nc
            tmp = rand(nr,1); 
            idx = find(tmp < prob);
            len = length(idx); 
            II(cnt+[1:len]) = idx;  
            JJ(cnt+[1:len]) = j*ones(len,1);  
            cnt = cnt + len; 
         end
         II = II(1:cnt); JJ = JJ(1:cnt); p = cnt; 
         %%
         Jcol = compJcol(JJ); 
         bb = Amap_MatComp(M,II,Jcol); 
         B  = spconvert([II,JJ,bb; n,n,0]); 
         normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
         if strcmp(scenario,'noiseless')
            xi = sparse(p,1); 
            sigma = 0; 
         else
            randnvec = randn(p,1);
            sigma = noiseratio*norm(bb)/norm(randnvec); 
            xi = sigma*randnvec; 
            B  = B + spconvert([II,JJ,xi; nr,nc,0]); 
         end
         [II,JJ,bb] = find(B);
         Jcol = compJcol(JJ); 
         %%------------------------------------------------
         %% evaluate the regularization parameter mu
         %%
         noiseratio = norm(xi)/norm(bb); 
         fprintf('\n Problem: n = %d, p = %d, r = %d,',n,p,r); 
         fprintf(' p/dr = %3.2e, p/n^2 = %3.2e%%',p/dr, p/(n^2)*100)
         fprintf('\n sigma = %3.2e,',sigma); 
         fprintf('\n noise ratio = %2.1e',noiseratio); 
         %%-----------------------------------------------
         tstart = clock;
         Amap  = @(X) Amap_MatComp(X,II,Jcol);
         if (exist('mexspconvert')==3)
            ATmap = @(y) mexspconvert(nr,nc,y,II,Jcol); 
         else
            ATmap = @(y) spconvert([II,JJ,y; nr,nc,0]); 
         end
         par.tol     = 1e-4;
         par.verbose = 1;
         par.plotyes = 0;   
         m2 = 0;
         if strcmp(scenario,'noiseless')
            m1 = 0; m3 = length(bb);
         else
            m1 = length(bb); m3 = 0;
         end
         delta = noiseratio*norm(bb); 
	 if strcmp(method,'dualPPA')                           
            [X,iter,time,sd,hist] = ...
            dualPPA(Amap,ATmap,bb,delta,nr,nc,m1,m2,m3,par);
	 elseif strcmp(method,'primPPA')
            par.continuation = 0; 
            [X,iter,time,sd,hist] = ...
            primPPA(Amap,ATmap,bb,delta,nr,nc,m1,m2,m3,par);
         end
         if isstruct(X)
            normX = sqrt(sum(sum((X.U'*X.U).*(X.V'*X.V))));
            trXM = sum(sum((M.U'*X.U).*(M.V'*X.V)));
         else
            normX = norm(X,'fro'); trXM = sum(sum(M.U.*(X*M.V))); 
         end
         mse = sqrt(normX^2+normM^2-2*trXM)/normM;
         runhist.mu(randstate)    = min(hist.mu);
         runhist.mumax(randstate) = max(hist.mu); 
         runhist.time(randstate)  = etime(clock,tstart);
         runhist.iter(randstate)  = iter;
         runhist.obj(randstate)   = hist.obj(end);
         runhist.mse(randstate)   = mse; 
         runhist.svp(randstate)   = hist.svp(end);
         %%
         %% report results in a table
         %%
         fprintf('\n Problem: nr = %d, nc = %d, p = %d, r = %d,',nr,nc,p,r); 
         fprintf(' p/dr = %3.2e, p/n^2 = %3.2e%%',p/dr, p/(n^2)*100)
         fprintf('\n sigma = %3.2e',sigma)
         fprintf('\n-----------------------------------------------');
         fprintf('------------------------------')
         fprintf('\n iterations         :  %5.0d',runhist.iter(randstate));
         fprintf('\n # singular         :  %5.0d',runhist.svp(randstate));
         fprintf('\n obj  value         :  %5.3e',runhist.obj(randstate));
         fprintf('\n cpu   time         :  %5.2e',runhist.time(randstate));
         fprintf('\n relative MSE       :  %5.2e',runhist.mse(randstate));
         fprintf('\n------------------------------------------------'); 
         fprintf('------------------------------\n')
     end
  end
%%*************************************************************************
