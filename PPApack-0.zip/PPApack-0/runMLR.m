%%************************************************************************
%% run multivariate linear regression problems: 
%% 
%% min { 0.5*norm(H-G*X,'fro')^2 + mu*sum(svd) } 
%% where G (nrxnr), H (nrxnc) are given matrices
%%
%% For details, see: 
%% [1] M. Yuan, A. Ekici, Z. Lu and R.D.C. Monteiro,  
%%     Dimension Reduction and Coefficient Estimation in the 
%%     Multivariate Linear Regression, 
%%     Journal of the Royal Statistical Society, Series B, 69(3):329-346, 2007.
%%
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh 
%%************************************************************************

    clear all;
    warning off; 
%%
    addpath('PROPACKmod');
    addpath('solver');
%%
    eg = 1; 
    noiseratio = 0.01; 
    randn('state',1); 
    rand('state',1); 
    if (eg==1)
       nr = 500; nc = 250; r = 50; 
       G = diag(rand(nr,1)); 
       M.U = randn(nr,r); M.V = randn(nc,r); 
       normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
       randmat = randn(size(G,1),nc);
       H = (G*M.U)*M.V'; 
       H = H + noiseratio*norm(H,'fro')*randmat/norm(randmat,'fro');
    else
       nr = 500; nc = 250; r = 50; 
       A = rand(10*nc,2*nc); 
       M.U = randn(nr,r); M.V = randn(nc,r); 
       normM = sqrt(sum(sum((M.U'*M.U).*(M.V'*M.V))));
       randmat = randn(size(A,1),nc);
       B = (A*M.U)*M.V'; 
       B = B + noiseratio*norm(B,'fro')*randmat/norm(randmat,'fro');
       [UA,SA,VA] = mexsvd(A); 
       G = diag(diag(SA)); 
       H = UA'*B; 
       M.U = VA'*(M.U); 
    end
%%
    tstart = clock;
    bb = H(:); 
    Amap  = @(X) Amap_MLR(X,G);
    ATmap = @(y) ATmap_MLR(y,G);
    par.tol     = 1e-4;
    par.verbose = 1;
    par.plotyes = 1;
    par.truncation     = 1; 
    par.truncation_gap = 50; 
    m1 = length(bb); m2 = 0; m3 = 0; 
    delta = noiseratio*norm(H,'fro'); 
    [X,iter,time,sd,hist] = ...
     dualPPA(Amap,ATmap,bb,delta,nr,nc,m1,m2,m3,par);
%%
    if exist('M'); 
       if isstruct(X)
          normX = sqrt(sum(sum((X.U'*X.U).*(X.V'*X.V))));
          trXM = sum(sum((M.U'*X.U).*(M.V'*X.V)));
       else
          normX = norm(X,'fro'); trXM = sum(sum(M.U.*(X*M.V))); 
       end
       mse = sqrt(normX^2+normM^2-2*trXM)/normM;
       runhist.mse   = mse; 
    end
    runhist.time  = etime(clock,tstart);
    runhist.iter  = iter;
    runhist.obj   = hist.obj(end);
    runhist.svp   = hist.svp(end);
    %%
    %% report results in a table
    %%
    fprintf(' Problem: nr = %d, nc = %d',nr,nc); 
    fprintf('\n-----------------------------------------------');
    fprintf('------------------------------')
    fprintf('\n iterations         :  %6.0f',runhist.iter);
    fprintf('\n # singular         :  %6.0f',runhist.svp);
    fprintf('\n obj  value         :  %6.5e',runhist.obj);
    fprintf('\n cpu   time         :  %6.2e',runhist.time);
    fprintf('\n mean square error  :  %6.2e',runhist.mse);
    fprintf('\n------------------------------------------------'); 
    fprintf('------------------------------\n')
%%************************************************************************
