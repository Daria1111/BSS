
[Introduction]
NuNoMin version 0: 
A MATLAB software for semidefinite programming
Copyright (c) 2009 by

This is software package for solving a nuclear norm
minimization problem of the form: 

(NNM) min { sum(svd(X)): A(X) \in b+Q } 
where the linear map A and the vector b are given, 
and the nrxnc matrix is the decision variable.  

Two main algorithms, 
(a) primal proximal point method,
(b) dual proximal point method,
are implemented to solve (P); 
details can be found in the following reference.  

[Reference]
[1] Y.J. Liu, D.F. Sun, and K.C. Toh,    
    An implementable proximal point algorithmic framework for 
    nuclear norm minimization,  preprint, National University of Singapore, 
    Jul 2009.
Available at: http://www.optimization-online.org/DB_HTML/2009/07/2340.html

[Copyright] 
See Copyright.txt

--------------------------------------------------------------
[Installation] 
The software NuNoMin requires a few mex-files that you may need
to compile in MATLAB. 
To so, run MATALB in the directory NuNoMin, then type: 

>> Installmex 

After that, to see whether you have installed the software
correctly, type the following in MATLAB: 

>> runRandomMatComp
--------------------------------------------------------------