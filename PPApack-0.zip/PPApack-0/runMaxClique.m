%%************************************************************************
%% random maximum clique problem for a graph (V,E). 
%% A clique of size n can be found by solving the following 
%% rank minimization problem: 
%%
%% min { rank(X) : <X,E> >= n^2, X_{ij} = 0 if (i,j)\not\in E, abs(i-j)>0 }.  
%% 
%% Here we solve its nuclear norm relaxed problem: 
%% min { sum(svd(X)) : <X,E> >= n^2, X_{ij} = 0 if (i,j)\not\in E, abs(i-j)>0 }.  
%%
%% Reference: 
%% B.P.W Ames, and S.A. Vavasis,
%% Nuclear Norm minimization for the planted clique and 
%% biclique problems, preprint, 2009. 
%%   
%% Copyright (c) 2009 by
%% Yongjin Liu, Defeng Sun, and Kim-Chuan Toh 
%%************************************************************************

  warning off; 
  clear all;
%%
  addpath('solver');
  addpath('PROPACKmod');
%%
  Ndim = [100,500];
  fname = 'Random-Max-Clique'; 
  for kk = 1;
     N = Ndim(kk);
     for n = ceil(0.2*N); %% the threshold is about 0.15
        cnt = 0;
        II = zeros(n,1); JJ = zeros(n,1);
        for j=1:N
            randstate = 5*j;
            rand('twister',double(randstate));
            if (j <= n)
               tmp = rand(N-n,1);
               idx = find(tmp<0.5);
               len = length(idx);
               II(cnt+(1:len)) = n+idx;
            else
               tmp = rand(N,1);
               idx = find(tmp<0.5);
               len = length(idx);
               II(cnt+(1:len)) = idx;
            end
            JJ(cnt+(1:len)) = j*ones(len,1);
            cnt = cnt+len;
        end
        II = II(1:cnt); JJ = JJ(1:cnt);
        Jcol = compJcol(JJ);
        %%
        delta = 0;
        m1 = 0; m2 = 1; m3 = length(II);
        m  = m1+m2+m3;
        b  = zeros(m,1);
        const = N;
        b(1)  = n^2/const;
        Amap  = @(X) Amap_MaxClique(X,II,Jcol,const);
        ATmap = @(y) ATmap_MaxClique(y,II,Jcol,N,const);
        %%
        tstart  = clock;
        par.tol          = 1e-5;
        par.continuation = 0; 
        par.verbose      = 1;
        par.plotyes      = 1;       
        [X,iter,time,sd,hist] = dualPPA(Amap,ATmap,b,delta,N,N,m1,m2,m3,par);
        GL = spalloc(N,1,n);
        GL = [ones(n,1);zeros(N-n,1)];
        GR = GL;
        normG = n;
        %% X = ceil(abs(X)-0.5); % refine X
        if isstruct(X)
           normX = sqrt(sum(sum((X.U'*X.U).*(X.V'*X.V))));
           trXG = sum(sum((GL'*X.U).*(GR'*X.V)));
        else
           normX = norm(X,'fro'); trXG = sum(sum(GL.*(X*GR)));
        end
        mse = sqrt(normX^2+normG^2-2*trXG)/normG;
        runhist.iter   = iter;
        runhist.svp    = hist.svp(end);
        runhist.obj    = hist.obj(end);
        runhist.time   = etime(clock,tstart);
        runhist.mse    = mse;
        %%
        %% report the result in a table
        %%
        fprintf('\n Problem: %s, N = %d, n = %d',fname,N,n);
        fprintf('\n          m1 = %d, m2 = %d, m3 = %d',m1,m2,m3);
        fprintf('\n-----------------------------------------------');
        fprintf('------------------------------')
        fprintf('\n iterations         :  %5.0d',runhist.iter);
        fprintf('\n # singular         :  %5.0d',runhist.svp);
        fprintf('\n obj  value         :  %5.3e',runhist.obj);
        fprintf('\n cpu   time         :  %5.2e',runhist.time);
        fprintf('\n relative MSE       :  %5.2e',runhist.mse);
        fprintf('\n-----------------------------------------------');
        fprintf('------------------------------\n')
     end
  end
%%************************************************************************
