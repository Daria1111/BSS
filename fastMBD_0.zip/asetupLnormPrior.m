function P = asetupLnormPrior(q,alpha,beta,alphap)

% alphap is used only in q = 1.5

switch q
    case 2 % L2 norm (Tichonov)
        P.fh = @(x,nx) (beta*x./(2*alpha+beta));
    case 1 % L1 norm (TV)
        v_star = 0;
        u_star = alpha/beta;
        P.fh = @(x,nx) aLn(x,nx,u_star,u_star-v_star);
    case 0 % L0 norm 
        v_star = sqrt(2*alpha/beta);
        u_star = sqrt(2*alpha/beta);
        P.fh = @(x,nx) aLn(x,nx,u_star,u_star-v_star);
    case 1.5 % Combination of L1 and L2 (not really L1.5 norm)
        if nargin<4
            alphap = alpha;
        end
        u_star = alpha/beta;
        u_starp = 0.5*alpha/alphap + u_star;
        k = beta/(2*alphap+beta);
        P.fh = @(x,nx) aL1_2(x,nx,u_star,u_starp,k);
    otherwise % for 0<q<1
        leftmarker = fzero( @(v) -v+alpha/beta*v^(q-1)*(1-q)*q, [eps 10]);
        v_star = fzero( @(v) -0.5*v^2+alpha/beta*v^q*(1-q), [leftmarker 10]);
        u_star = v_star + alpha/beta*q*v_star^(q-1);
        P.fh = @(x,nx) aLn(x,nx,u_star,u_star-v_star);
end


        