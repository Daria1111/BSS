function ZI = iminterp2(Z,srf,method)

% perform interpolation on color image (3D array)
% interpolate Z by srf-x using technique "method" 
%

if length(srf) == 1
   srf = [srf srf];
end

if nargin < 3
   method = 'linear';
end

for i = 1:size(Z,3)
   A = [[Z(1,1,i) Z(1,:,i) Z(1,end,i)]; ...
      [Z(:,1,i) Z(:,:,i) Z(:,end,i)]; ...
      [Z(end,1,i) Z(end,:,i) Z(end,end,i)] ];
   
   ZI(:,:,i) = interp2(A,...
      linspace(1.5+1/srf(2)/2,size(Z,2)+1.5-1/srf(2)/2,round(size(Z,2)*srf(2))),...
      linspace(1.5+1/srf(1)/2,size(Z,1)+1.5-1/srf(1)/2,round(size(Z,1)*srf(1))).',...
      method);
end
   


