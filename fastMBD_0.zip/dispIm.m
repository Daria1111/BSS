function dispIm(y)

imagesc(linscale(y));
colormap(gray(255));
axis image;