function V = aL1_2(DU,normDU,u_star,u_starp,k)
%
% V = aL1_2(DU,normDU,u_star,k)
%
% half-quadratic algorithm 
% additive version
%
% For prior function phi(u), which combines L1 and L2
% 
% phi(u) = a*(|u| + t),     |u|> u_starp 
% phi(u) = a'*u^2,          |u|<=u_starp 
%
% t is such that phi(s) is continuous
%
% Shrinkage formula:
% min_v { b/2*(u-v)^2 + phi(v) } 
%
% v = k*u,          |u|<ustarp
% v = sign(u)(|u|- ustar),   elsewhere
%
% ustar = a/(2*a') + a/b


V = k*DU;
DUp = DU(normDU>u_starp);
normDUp = normDU(normDU>u_starp);
V(normDU>u_starp) = DUp.*(normDUp-u_star)./normDUp; 

